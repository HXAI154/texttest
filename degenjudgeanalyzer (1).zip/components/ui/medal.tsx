import { Medal } from "lucide-react"

export { Medal }

